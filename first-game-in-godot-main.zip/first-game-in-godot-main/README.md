# First game in Godot
Project files for our video on making your first game in Godot.

Check out the videos on the [Brackeys YouTube Channel](http://youtube.com/brackeys).

Everything is free to use, also commercially (public domain).
